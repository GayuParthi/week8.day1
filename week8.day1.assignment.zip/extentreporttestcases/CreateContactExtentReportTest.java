package extentreporttestcases;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import createcontactextentreport.LoginPageExtentReport;
import week8.day1.assignment.BasePageExtentReports;

public class CreateContactExtentReportTest extends BasePageExtentReports {
	@BeforeTest
	public void setData()
	{
		testName="UserName";
		TestDescription="Verify Username";
		Author="Gayathri";
		category="regression";
	}
	@Test
	public void createContactExtentReportTest() throws IOException {
		new LoginPageExtentReport()
		.typeUserName("DemoCSR")
		.typePassword("crmsfa")
		.clickLogin1()
		.clickCRMSFA()
		.clickContacts()
		.clickCreateContact()
		.typeFirstName("Abinaya")
		.typeLastName("Shree")
		.typeFirstNameLocal("Sudheera")
		.typeLastNameLocal("Shri")
		.typeDepartmentName("EIE")
		.typeDescription("Electronics and Instrumentation Engineering")
		.typeprimaryEmail("sudheera96@gmail.com")
		.clickCreateContactButton()
		.clickEditButton()
		.clearAndTypeDescription()
		.clickUpdateContact()
		.verifyContact();
		
	}
	

}
