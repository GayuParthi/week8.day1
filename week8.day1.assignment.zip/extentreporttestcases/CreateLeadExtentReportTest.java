package extentreporttestcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import createleadextentreport.LoginPage1ExtentReport;
import week8.day1.assignment.BasePageExtentReports;

public class CreateLeadExtentReportTest extends BasePageExtentReports{
	@BeforeTest
	public void setData()
	{
		testName="Password Entered";
		TestDescription="Verify Password";
		Author="Gayathri";
		category="smoke";
	}
	
	@Test
	public void createLeadExtentReportTest() throws IOException {
		new LoginPage1ExtentReport()
		.typeUserName("DemoCSR")
		.typePassword("crmsfa")
		.clickLogin1()
		.clickCRMSFA()
		.clickLeadsTab()
		.clickcreateLead()
		.enterFirstName("Gayathri")
		.enterLastName("SK")
		.enterCompanyName("CTS")
		.clickSubmit()
		.verifyFirstName();
	}

}
