package extentreporttestcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import duplicateleadextentreportpages.LoginPage4ExtentReport;
import week8.day1.assignment.BasePageExtentReports;

public class DuplicateLeadExtentReportTest extends BasePageExtentReports{
	@BeforeTest
	public void setData()
	{
		testName="Login completed successfully";
		TestDescription="Login Verified";
		Author="Gayathri";
		category="Sanity";
	}
	@Test
	public void duplicateLeadExtentReportTest() throws InterruptedException, IOException {
		new LoginPage4ExtentReport()
		.typeUserName("DemoCSR")
		.typePassword("crmsfa")
		.clickLogin2()
		.clickCRMSFA3()
		.clickLeadsButton3()
		.clickFindLeads3()
		.clickEmail1()
		.typeEmailAddress3("abc@gmail.com")
		.clickFindLeadsButton4()
		.clickFirstLeadId3()
		.clickDuplicateButton2()
		.verifyDuplicateLead3()
		.clickCreateLead3()
		.viewLead_FirstName()
		.verify_Captured_LeadId();
		
	}

}
