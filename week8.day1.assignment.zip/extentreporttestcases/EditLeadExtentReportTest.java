package extentreporttestcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import editleadextentreportpages.LoginPage2ExtentReport;
import week8.day1.assignment.BasePageExtentReports;

public class EditLeadExtentReportTest extends BasePageExtentReports{
	@BeforeTest
	public void setData()
	{
		testName="Login completed successfully";
		TestDescription="Login Verified";
		Author="Gayathri";
		category="Sanity";
	}

	@Test
	public void editLeadExtentReportTest() throws InterruptedException, IOException {
	     new LoginPage2ExtentReport()
	     .typeUserName("DemoCSR")
	     .typePassword("crmsfa")
	     .clickLogin2()
	     .clickCRMSFA2()
	     .clickLeadsButton()
	     .clickFindLeads()
	     .typeFirstName("Hari")
	     .clickFindLeadsButton()
	     .clickFirstLeadId()
	     .clickEditButton1()
	     .clearCompanyName()
	     .updateCompanyName("EMC")
	     .clickUpdateButton1()
	     .verifyUpdatedCompanyName();

}
}
