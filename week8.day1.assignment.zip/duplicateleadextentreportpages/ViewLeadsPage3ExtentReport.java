package duplicateleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class ViewLeadsPage3ExtentReport extends BasePageExtentReports{
	public DuplicateLeadPage1ExtentReport clickDuplicateButton2() {
		getDriver().findElement(By.linkText("Duplicate Lead")).click();
		return new DuplicateLeadPage1ExtentReport();
	}

}
