package duplicateleadextentreportpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import week8.day1.assignment.BasePageExtentReports;

public class FindLeadsPage1ExtentReport extends BasePageExtentReports{
	public FindLeadsPage1ExtentReport clickEmail1() {
		getDriver().findElement(By.linkText("Email")).click();
		return this;
	}
	public FindLeadsPage1ExtentReport typeEmailAddress3(String email) {
		getDriver().findElement(By.name("emailAddress")).sendKeys(email);
		return this;
	}
	public FindLeadsPage1ExtentReport clickFindLeadsButton4() throws InterruptedException {
		getDriver().findElement(By.xpath("//button[contains(text(), 'Find Leads')]")).click();
		Thread.sleep(1000);
		return this;
	}
	public ViewLeadsPage3ExtentReport clickFirstLeadId3() {
		WebElement leadFirstName = getDriver().findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]/a"));
		String capturedLeadName = leadFirstName.getText();
		System.out.println(capturedLeadName);
		leadFirstName.click();
		return new ViewLeadsPage3ExtentReport();
	}


}
