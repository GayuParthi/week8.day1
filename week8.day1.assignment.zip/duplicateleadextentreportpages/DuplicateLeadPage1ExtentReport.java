package duplicateleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class DuplicateLeadPage1ExtentReport extends BasePageExtentReports{
	public DuplicateLeadPage1ExtentReport verifyDuplicateLead3() {
		if(getDriver().getTitle().contains("Duplicate Lead")) {
			System.out.println("The title contains the word Duplicate Lead");
		}else {
			System.out.println("The title does not contain the word Duplicate Lead");
		}
		return this;
	}
	public ViewleadsPage4ExtentReport clickCreateLead3() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewleadsPage4ExtentReport();
	}

}
