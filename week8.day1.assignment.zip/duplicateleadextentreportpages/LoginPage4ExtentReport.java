package duplicateleadextentreportpages;

import java.io.IOException;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class LoginPage4ExtentReport extends BasePageExtentReports{
	public LoginPage4ExtentReport typeUserName(String username) {
		getDriver().findElement(By.id("username")).sendKeys(username);
		return this;
	}
	public LoginPage4ExtentReport typePassword(String password) {
		getDriver().findElement(By.id("password")).sendKeys(password);
		return this; 
	}
	public HomePage4ExtentReport clickLogin2() throws IOException {
		try {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		reportStep("Login completed successfully", "Pass");
		}catch(Exception e) {
			reportStep("Unable to Login", "Fail");
		}
		return new HomePage4ExtentReport();
	} 

}
