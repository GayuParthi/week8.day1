package duplicateleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class ViewleadsPage4ExtentReport extends BasePageExtentReports{
	String capturedLeadName;
	String duplicatedLeadName;
	public ViewleadsPage4ExtentReport viewLead_FirstName() {
		String duplicatedLeadName = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		System.out.println(duplicatedLeadName);
		return this;
	}
	public ViewleadsPage4ExtentReport verify_Captured_LeadId() {
		
		Object capturedLeadName = getDriver();
		Object duplicatedLeadName = getDriver();
		if(capturedLeadName.equals(duplicatedLeadName)) {
	    	System.out.println("Duplicated lead name is same as Captured name");
	    }else {
	    	System.out.println("Duplicated lead name is not same as Captured name");
	    }
		return this;
	}


}
