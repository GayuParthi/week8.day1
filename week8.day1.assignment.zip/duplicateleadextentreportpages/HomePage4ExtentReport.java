package duplicateleadextentreportpages;

import org.openqa.selenium.By;


import week8.day1.assignment.BasePageExtentReports;

public class HomePage4ExtentReport extends BasePageExtentReports {
	public LeadsPage1ExtentReport clickCRMSFA3() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new LeadsPage1ExtentReport ();
	}

}
