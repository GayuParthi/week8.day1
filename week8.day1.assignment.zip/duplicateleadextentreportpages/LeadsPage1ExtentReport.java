package duplicateleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class LeadsPage1ExtentReport extends BasePageExtentReports {
	public LeadsPage1ExtentReport clickLeadsButton3() {
		getDriver().findElement(By.linkText("Leads")).click();
		return this;
	}
	public FindLeadsPage1ExtentReport clickFindLeads3() {
		getDriver().findElement(By.linkText("Find Leads")).click();
		return new FindLeadsPage1ExtentReport();
	}

}
