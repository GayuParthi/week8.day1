package createcontactextentreport;

import org.openqa.selenium.By;


import week8.day1.assignment.BasePageExtentReports;

public class EditContactPageExtentReport extends BasePageExtentReports {
	public EditContactPageExtentReport clearAndTypeDescription() {
		getDriver().findElement(By.id("updateContactForm_description")).clear();
		getDriver().findElement(By.id("updateContactForm_importantNote")).sendKeys("Confidential");
		return this;
	}
	public ViewMyCreateContactPageExtentReport clickUpdateContact() {
		getDriver().findElement(By.xpath("//input[@value='Update']")).click();
		return new ViewMyCreateContactPageExtentReport();
	}
	

}
