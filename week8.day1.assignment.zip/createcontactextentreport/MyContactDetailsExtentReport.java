package createcontactextentreport;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import week8.day1.assignment.BasePageExtentReports;

public class MyContactDetailsExtentReport extends BasePageExtentReports {
	public MyContactDetailsExtentReport typeFirstName(String fname) {
		WebElement elementFirstName = getDriver().findElement(By.id("firstNameField"));
		elementFirstName.sendKeys(fname);
		return this;
	}
	public MyContactDetailsExtentReport typeLastName(String lName) {
		getDriver().findElement(By.id("lastNameField")).sendKeys(lName);
		return this;
	}
	public MyContactDetailsExtentReport typeFirstNameLocal(String fNameLocal) {
		getDriver().findElement(By.id("createContactForm_firstNameLocal")).sendKeys(fNameLocal);
		return this;
	}
	public MyContactDetailsExtentReport typeLastNameLocal(String lNameLocal) {
		getDriver().findElement(By.id("createContactForm_lastNameLocal")).sendKeys(lNameLocal);
		return this;
	}
	public MyContactDetailsExtentReport typeDepartmentName(String dept) {
		getDriver().findElement(By.id("createContactForm_departmentName")).sendKeys(dept);
		return this;
	}
	public MyContactDetailsExtentReport typeDescription(String descip) {
		getDriver().findElement(By.id("createContactForm_description")).sendKeys(descip);
		return this;
	}
	public MyContactDetailsExtentReport typeprimaryEmail(String email) {
		getDriver().findElement(By.id("createContactForm_primaryEmail")).sendKeys(email);
		return this;
	}
	
	public ViewContactPageExtentReport clickCreateContactButton() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewContactPageExtentReport();
	}

}
