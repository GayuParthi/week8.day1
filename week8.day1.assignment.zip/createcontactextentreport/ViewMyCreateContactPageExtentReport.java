package createcontactextentreport;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class ViewMyCreateContactPageExtentReport extends BasePageExtentReports {
	public ViewMyCreateContactPageExtentReport verifyContact() {
		String contactName = getDriver().findElement(By.id("viewContact_fullName_sp")).getText();
		System.out.println("Created Contact Name is :: "+contactName);
		return this;
	}

}
