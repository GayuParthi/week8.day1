package createcontactextentreport;

import org.openqa.selenium.By;


import week8.day1.assignment.BasePageExtentReports;

public class ContactsPageExtentReport extends BasePageExtentReports{
	public ContactsPageExtentReport clickContacts() {
		getDriver().findElement(By.partialLinkText("Contacts")).click();
		return this;
	}
	public MyContactDetailsExtentReport clickCreateContact() {
		getDriver().findElement(By.partialLinkText("Create Contact")).click();
		return new MyContactDetailsExtentReport();
	}

}
