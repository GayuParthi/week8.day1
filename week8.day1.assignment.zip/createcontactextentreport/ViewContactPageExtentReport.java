package createcontactextentreport;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class ViewContactPageExtentReport extends BasePageExtentReports{
	public EditContactPageExtentReport clickEditButton() {
		getDriver().findElement(By.linkText("Edit")).click();
		return new EditContactPageExtentReport();
	}
}
