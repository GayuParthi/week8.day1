package createcontactextentreport;

import java.io.IOException;

import org.openqa.selenium.By;


import week8.day1.assignment.BasePageExtentReports;

public class LoginPageExtentReport extends BasePageExtentReports {
	 
		public LoginPageExtentReport typeUserName(String username) throws IOException {
			try {
			getDriver().findElement(By.id("username")).sendKeys(username);
			reportStep("Entered username successfully", "Pass");
			}catch(Exception e) {
				reportStep("Unable to enter username", "Fail");
			}
			return this;
		}

		public LoginPageExtentReport typePassword(String password) {
			getDriver().findElement(By.id("password")).sendKeys(password);
			return this; 
		}
		public HomePage1ExtentReport clickLogin1() {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			return new HomePage1ExtentReport();
		}

}
