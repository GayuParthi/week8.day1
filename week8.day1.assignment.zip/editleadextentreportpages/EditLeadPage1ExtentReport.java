package editleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class EditLeadPage1ExtentReport extends BasePageExtentReports{
	public EditLeadPage1ExtentReport clearCompanyName() {
		getDriver().findElement(By.id("updateLeadForm_companyName")).clear();
		return this;
	}
	public EditLeadPage1ExtentReport updateCompanyName(String cmpname) {
		getDriver().findElement(By.id("updateLeadForm_companyName")).sendKeys(cmpname);
		return this;
	}
	public ViewLeadsPage2ExtentReport clickUpdateButton1() {
		getDriver().findElement(By.xpath("(//input[@class='smallSubmit'])")).click();
		return new ViewLeadsPage2ExtentReport();
	}

}
