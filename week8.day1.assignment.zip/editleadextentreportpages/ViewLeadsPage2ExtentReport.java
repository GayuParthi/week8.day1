package editleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class ViewLeadsPage2ExtentReport extends BasePageExtentReports{
	public ViewLeadsPage2ExtentReport verifyUpdatedCompanyName() {
		String companyName = getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		System.out.println("Updated Company Name :: "+companyName);
		String firstName = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		System.out.println("First Name Of the Lead:: "+firstName);
		return this;
	}

}
