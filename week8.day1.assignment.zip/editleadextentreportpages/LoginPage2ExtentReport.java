package editleadextentreportpages;

import java.io.IOException;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class LoginPage2ExtentReport extends BasePageExtentReports {
	public LoginPage2ExtentReport typeUserName(String username) {
		getDriver().findElement(By.id("username")).sendKeys(username);
		return this;
	}
	public LoginPage2ExtentReport typePassword(String password) {
		getDriver().findElement(By.id("password")).sendKeys(password);
		return this; 
	}
	public HomePage3ExtentReport clickLogin2() throws IOException {
		try {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		reportStep("Login completed successfully", "Pass");
		}catch(Exception e) {
			reportStep("Unable to Login", "Fail");
		}
		return new HomePage3ExtentReport();
	} 

}
