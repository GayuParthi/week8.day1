package editleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class LeadsPageExtentReport extends BasePageExtentReports{
	public LeadsPageExtentReport clickLeadsButton() {
		getDriver().findElement(By.linkText("Leads")).click();
		return this;
	}
	public FindLeadsPageExtentReport clickFindLeads() {
		getDriver().findElement(By.linkText("Find Leads")).click();
		return new FindLeadsPageExtentReport();
	}
	

}
