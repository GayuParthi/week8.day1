package editleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class ViewLeadsPage1ExtentReport extends BasePageExtentReports{
	public EditLeadPage1ExtentReport clickEditButton1() {
		getDriver().findElement(By.xpath("//a[text()='Edit']")).click();
		return new EditLeadPage1ExtentReport();

	}

}
