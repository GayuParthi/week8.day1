package editleadextentreportpages;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class FindLeadsPageExtentReport extends BasePageExtentReports{
	public FindLeadsPageExtentReport typeFirstName(String fname) {
		getDriver().findElement(By.xpath("(//input[@name='firstName'])[3]")).sendKeys(fname);
		return this;
	}
	public FindLeadsPageExtentReport clickFindLeadsButton() {
		getDriver().findElement(By.xpath("//button[text()='Find Leads']")).click();
		return this;
	}
	public ViewLeadsPage1ExtentReport clickFirstLeadId() throws InterruptedException {
		getDriver().findElement(By.xpath("(//a[@href='/crmsfa/control/viewLead?partyId=10171'])")).click();
		Thread.sleep(2000);
		return new ViewLeadsPage1ExtentReport();
	}

}
