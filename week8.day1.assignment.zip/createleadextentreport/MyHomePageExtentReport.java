package createleadextentreport;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class MyHomePageExtentReport extends BasePageExtentReports{
	public MyLeadsPageExtentReport clickLeadsTab() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new MyLeadsPageExtentReport();
	}

}
