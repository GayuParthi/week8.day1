package createleadextentreport;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class MyLeadsPageExtentReport extends BasePageExtentReports{
	public CreateLeadPageExtentReport clickcreateLead() {
		getDriver().findElement(By.xpath("//a[text()='Create Lead']")).click();	
		return new CreateLeadPageExtentReport();
	}

}
