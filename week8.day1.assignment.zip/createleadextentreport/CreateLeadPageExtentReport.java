package createleadextentreport;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class CreateLeadPageExtentReport extends BasePageExtentReports{
	public CreateLeadPageExtentReport enterFirstName(String fname) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		return this;
	}
	public CreateLeadPageExtentReport enterLastName(String lname) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		return this;
	}
	public CreateLeadPageExtentReport enterCompanyName(String compname) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(compname);
		return this;
	}
	
public ViewLeadsPageExtentReport clickSubmit() {
	getDriver().findElement(By.xpath("//input[@value='Create Lead']")).click();
	return new ViewLeadsPageExtentReport();
}
	

}
