package createleadextentreport;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class ViewLeadsPageExtentReport extends BasePageExtentReports{
	public ViewLeadsPageExtentReport verifyFirstName() {
		String text = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
	    System.out.println("First name = "+text);
		return this;
	}

}
