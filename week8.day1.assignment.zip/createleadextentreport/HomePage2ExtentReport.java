package createleadextentreport;

import org.openqa.selenium.By;

import week8.day1.assignment.BasePageExtentReports;

public class HomePage2ExtentReport extends BasePageExtentReports{
	public MyHomePageExtentReport clickCRMSFA() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePageExtentReport();
	}
	

}
